# Find the ASCII values of characters in INDIA and then return sum of exponentials of those values.
# How much Anmol singh paid for his DLF apartment via Capbridge? 
# What do you know about Don Tapscott and Anthony Williams?
# What is the relationship between Gensol and Go-Auto?
# which course are we teaching on Canvas LMS? "H:\DownloadsH\How to use Canvas LMS.pdf"
# Summarize this page: https://theschoolof.ai/
# What is the log value of the amount that Anmol singh paid for his DLF apartment via Capbridge? Hint: use local 
# find the the main difference between latest BMW 7 and 5 series online. Reply back in detail and in markdown.
# How much money did Anmol Singh paid to DLF to buy an apartment in Camelias indirectly? Search local storage agian?
# What are the main differences between Mercedes S Class end E Class. Reply back in markdown list. 
# Who is the current chairman of DLF? Search local documents. 


